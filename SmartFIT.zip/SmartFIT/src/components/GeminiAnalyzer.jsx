﻿export { default } from './Analyzer';
